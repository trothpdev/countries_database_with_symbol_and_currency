-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 08, 2021 at 12:32 AM
-- Server version: 5.6.51-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trothmatrix_panel`
--

-- --------------------------------------------------------

--
-- Table structure for table `countriesWithFlag`
--

CREATE TABLE `countriesWithFlag` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `symbol` varchar(100) NOT NULL,
  `flag_code` varchar(100) NOT NULL,
  `small_flag_path` varchar(100) NOT NULL,
  `extralarge_flag_path` varchar(100) NOT NULL,
  `large_flag_path` varchar(100) NOT NULL,
  `medium_flag_path` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countriesWithFlag`
--

INSERT INTO `countriesWithFlag` (`id`, `name`, `currency`, `code`, `symbol`, `flag_code`, `small_flag_path`, `extralarge_flag_path`, `large_flag_path`, `medium_flag_path`) VALUES
(1, 'Albania', 'Leke', 'ALL', 'Lek', 'AL', 'flags/al.png', 'flags-extralarge/al.png', 'flags-large/al.png', 'flags-medium/al.png'),
(2, 'Afghanistan', 'Afghanis', 'AFN', '؋', 'AF', 'flags/af.png', 'flags-extralarge/af.png', 'flags-large/af.png', 'flags-medium/af.png'),
(3, 'Argentina', 'Pesos', 'ARS', '$', 'AR', 'flags/ar.png', 'flags-extralarge/ar.png', 'flags-large/ar.png', 'flags-medium/ar.png'),
(4, 'Aruba', 'Guilders', 'AWG', 'ƒ', 'AW', 'flags/aw.png', 'flags-extralarge/aw.png', 'flags-large/aw.png', 'flags-medium/aw.png'),
(5, 'Australia', 'Dollars', 'AUD', '$', 'AU', 'flags/au.png', 'flags-extralarge/au.png', 'flags-large/au.png', 'flags-medium/au.png'),
(6, 'Azerbaijan', 'New Manats', 'AZN', 'ман', 'AZ', 'flags/az.png', 'flags-extralarge/az.png', 'flags-large/az.png', 'flags-medium/az.png'),
(7, 'Bahamas', 'Dollars', 'BSD', '$', 'BS', 'flags/bs.png', 'flags-extralarge/bs.png', 'flags-large/bs.png', 'flags-medium/bs.png'),
(8, 'Barbados', 'Dollars', 'BBD', '$', 'BB', 'flags/bb.png', 'flags-extralarge/bb.png', 'flags-large/bb.png', 'flags-medium/bb.png'),
(9, 'Belarus', 'Rubles', 'BYR', 'p.', 'BY', 'flags/by.png', 'flags-extralarge/by.png', 'flags-large/by.png', 'flags-medium/by.png'),
(10, 'Belgium', 'Euro', 'EUR', '€', 'BE', 'flags/be.png', 'flags-extralarge/be.png', 'flags-large/be.png', 'flags-medium/be.png'),
(11, 'Beliz', 'Dollars', 'BZD', 'BZ$', 'BZ', 'flags/bz.png', 'flags-extralarge/bz.png', 'flags-large/bz.png', 'flags-medium/bz.png'),
(12, 'Bermuda', 'Dollars', 'BMD', '$', 'BM', 'flags/bm.png', 'flags-extralarge/bm.png', 'flags-large/bm.png', 'flags-medium/bm.png'),
(13, 'Bolivia', 'Bolivianos', 'BOB', '$b', 'BO', 'flags/bo.png', 'flags-extralarge/bo.png', 'flags-large/bo.png', 'flags-medium/bo.png'),
(14, 'Bosnia and Herzegovina', 'Convertible Marka', 'BAM', 'KM', 'BA', 'flags/ba.png', 'flags-extralarge/ba.png', 'flags-large/ba.png', 'flags-medium/ba.png'),
(15, 'Botswana', 'Pula', 'BWP', 'P', 'BW', 'flags/bw.png', 'flags-extralarge/bw.png', 'flags-large/bw.png', 'flags-medium/bw.png'),
(16, 'Bulgaria', 'Leva', 'BGN', 'лв', 'BG', 'flags/bg.png', 'flags-extralarge/bg.png', 'flags-large/bg.png', 'flags-medium/bg.png'),
(17, 'Brazil', 'Reais', 'BRL', 'R$', 'BR', 'flags/br.png', 'flags-extralarge/br.png', 'flags-large/br.png', 'flags-medium/br.png'),
(18, 'Britain (United Kingdom)', 'Pounds', 'GBP', '£', 'GB', 'flags/gb.png', 'flags-extralarge/gb.png', 'flags-large/gb.png', 'flags-medium/gb.png'),
(19, 'Brunei Darussalam', 'Dollars', 'BND', '$', 'BN', 'flags/bn.png', 'flags-extralarge/bn.png', 'flags-large/bn.png', 'flags-medium/bn.png'),
(20, 'Cambodia', 'Riels', 'KHR', '៛', 'KH', 'flags/kh.png', 'flags-extralarge/kh.png', 'flags-large/kh.png', 'flags-medium/kh.png'),
(21, 'Canada', 'Dollars', 'CAD', '$', 'CA', 'flags/ca.png', 'flags-extralarge/ca.png', 'flags-large/ca.png', 'flags-medium/ca.png'),
(22, 'Cayman Islands', 'Dollars', 'KYD', '$', 'KY', 'flags/ky.png', 'flags-extralarge/ky.png', 'flags-large/ky.png', 'flags-medium/ky.png'),
(23, 'Chile', 'Pesos', 'CLP', '$', 'CL', 'flags/cl.png', 'flags-extralarge/cl.png', 'flags-large/cl.png', 'flags-medium/cl.png'),
(24, 'China', 'Yuan Renminbi', 'CNY', '¥', 'CN', 'flags/cn.png', 'flags-extralarge/cn.png', 'flags-large/cn.png', 'flags-medium/cn.png'),
(25, 'Colombia', 'Pesos', 'COP', '$', 'CO', 'flags/co.png', 'flags-extralarge/co.png', 'flags-large/co.png', 'flags-medium/co.png'),
(26, 'Costa Rica', 'Colón', 'CRC', '₡', 'CR', 'flags/cr.png', 'flags-extralarge/cr.png', 'flags-large/cr.png', 'flags-medium/cr.png'),
(27, 'Croatia', 'Kuna', 'HRK', 'kn', 'HR', 'flags/hr.png', 'flags-extralarge/hr.png', 'flags-large/hr.png', 'flags-medium/hr.png'),
(28, 'Cuba', 'Pesos', 'CUP', '₱', 'CU', 'flags/cu.png', 'flags-extralarge/cu.png', 'flags-large/cu.png', 'flags-medium/cu.png'),
(29, 'Cyprus', 'Euro', 'EUR', '€', 'CY', 'flags/cy.png', 'flags-extralarge/cy.png', 'flags-large/cy.png', 'flags-medium/cy.png'),
(30, 'Czech Republic', 'Koruny', 'CZK', 'Kč', 'CZ', 'flags/cz.png', 'flags-extralarge/cz.png', 'flags-large/cz.png', 'flags-medium/cz.png'),
(31, 'Denmark', 'Kroner', 'DKK', 'kr', 'DK', 'flags/dk.png', 'flags-extralarge/dk.png', 'flags-large/dk.png', 'flags-medium/dk.png'),
(32, 'Dominican Republic', 'Pesos', 'DOP ', 'RD$', 'DO', 'flags/do.png', 'flags-extralarge/do.png', 'flags-large/do.png', 'flags-medium/do.png'),
(33, 'Egypt', 'Pounds', 'EGP', '£', 'EG', 'flags/eg.png', 'flags-extralarge/eg.png', 'flags-large/eg.png', 'flags-medium/eg.png'),
(34, 'El Salvador', 'Colones', 'SVC', '$', 'SV', 'flags/sv.png', 'flags-extralarge/sv.png', 'flags-large/sv.png', 'flags-medium/sv.png'),
(35, 'Falkland Islands', 'Pounds', 'FKP', '£', 'FK', 'flags/fk.png', 'flags-extralarge/fk.png', 'flags-large/fk.png', 'flags-medium/fk.png'),
(36, 'Fiji', 'Dollars', 'FJD', '$', 'FJ', 'flags/fj.png', 'flags-extralarge/fj.png', 'flags-large/fj.png', 'flags-medium/fj.png'),
(37, 'France', 'Euro', 'EUR', '€', 'FR', 'flags/fr.png', 'flags-extralarge/fr.png', 'flags-large/fr.png', 'flags-medium/fr.png'),
(38, 'Ghana', 'Cedis', 'GHC', '¢', 'GH', 'flags/gh.png', 'flags-extralarge/gh.png', 'flags-large/gh.png', 'flags-medium/gh.png'),
(39, 'Gibraltar', 'Pounds', 'GIP', '£', 'GI', 'flags/gi.png', 'flags-extralarge/gi.png', 'flags-large/gi.png', 'flags-medium/gi.png'),
(40, 'Greece', 'Euro', 'EUR', '€', 'GR', 'flags/gr.png', 'flags-extralarge/gr.png', 'flags-large/gr.png', 'flags-medium/gr.png'),
(41, 'Guatemala', 'Quetzales', 'GTQ', 'Q', 'GT', 'flags/gt.png', 'flags-extralarge/gt.png', 'flags-large/gt.png', 'flags-medium/gt.png'),
(42, 'Guernsey', 'Pounds', 'GGP', '£', 'GG', 'flags/gg.png', 'flags-extralarge/gg.png', 'flags-large/gg.png', 'flags-medium/gg.png'),
(43, 'Guyana', 'Dollars', 'GYD', '$', 'GY', 'flags/gy.png', 'flags-extralarge/gy.png', 'flags-large/gy.png', 'flags-medium/gy.png'),
(44, 'Holland (Netherlands)', 'Euro', 'EUR', '€', 'NL', 'flags/nl.png', 'flags-extralarge/nl.png', 'flags-large/nl.png', 'flags-medium/nl.png'),
(45, 'Honduras', 'Lempiras', 'HNL', 'L', 'HN', 'flags/hn.png', 'flags-extralarge/hn.png', 'flags-large/hn.png', 'flags-medium/hn.png'),
(46, 'Hong Kong', 'Dollars', 'HKD', '$', 'HK', 'flags/hk.png', 'flags-extralarge/hk.png', 'flags-large/hk.png', 'flags-medium/hk.png'),
(47, 'Hungary', 'Forint', 'HUF', 'Ft', 'HU', 'flags/hu.png', 'flags-extralarge/hu.png', 'flags-large/hu.png', 'flags-medium/hu.png'),
(48, 'Iceland', 'Kronur', 'ISK', 'kr', 'IS', 'flags/is.png', 'flags-extralarge/is.png', 'flags-large/is.png', 'flags-medium/is.png'),
(49, 'Indonesia', 'Rupiahs', 'IDR', 'Rp', 'ID', 'flags/id.png', 'flags-extralarge/id.png', 'flags-large/id.png', 'flags-medium/id.png'),
(50, 'Iran', 'Rials', 'IRR', '﷼', 'IR', 'flags/ir.png', 'flags-extralarge/ir.png', 'flags-large/ir.png', 'flags-medium/ir.png'),
(51, 'Ireland', 'Euro', 'EUR', '€', 'IE', 'flags/ie.png', 'flags-extralarge/ie.png', 'flags-large/ie.png', 'flags-medium/ie.png'),
(52, 'Isle of Man', 'Pounds', 'IMP', '£', 'IM', 'flags/im.png', 'flags-extralarge/im.png', 'flags-large/im.png', 'flags-medium/im.png'),
(53, 'Israel', 'New Shekels', 'ILS', '₪', 'IL', 'flags/il.png', 'flags-extralarge/il.png', 'flags-large/il.png', 'flags-medium/il.png'),
(54, 'Italy', 'Euro', 'EUR', '€', 'IT', 'flags/it.png', 'flags-extralarge/it.png', 'flags-large/it.png', 'flags-medium/it.png'),
(55, 'Jamaica', 'Dollars', 'JMD', 'J$', 'JM', 'flags/jm.png', 'flags-extralarge/jm.png', 'flags-large/jm.png', 'flags-medium/jm.png'),
(56, 'Japan', 'Yen', 'JPY', '¥', 'JP', 'flags/jp.png', 'flags-extralarge/jp.png', 'flags-large/jp.png', 'flags-medium/jp.png'),
(57, 'Jersey', 'Pounds', 'JEP', '£', 'JE', 'flags/je.png', 'flags-extralarge/je.png', 'flags-large/je.png', 'flags-medium/je.png'),
(58, 'Kazakhstan', 'Tenge', 'KZT', 'лв', 'KZ', 'flags/kz.png', 'flags-extralarge/kz.png', 'flags-large/kz.png', 'flags-medium/kz.png'),
(59, 'Korea (North)', 'Won', 'KPW', '₩', 'KP', 'flags/kp.png', 'flags-extralarge/kp.png', 'flags-large/kp.png', 'flags-medium/kp.png'),
(60, 'Korea (South)', 'Won', 'KRW', '₩', 'KR', 'flags/kr.png', 'flags-extralarge/kr.png', 'flags-large/kr.png', 'flags-medium/kr.png'),
(61, 'Kyrgyzstan', 'Soms', 'KGS', 'лв', 'KG', 'flags/kg.png', 'flags-extralarge/kg.png', 'flags-large/kg.png', 'flags-medium/kg.png'),
(62, 'Laos', 'Kips', 'LAK', '₭', 'LA', 'flags/la.png', 'flags-extralarge/la.png', 'flags-large/la.png', 'flags-medium/la.png'),
(63, 'Latvia', 'Lati', 'LVL', 'Ls', 'LV', 'flags/lv.png', 'flags-extralarge/lv.png', 'flags-large/lv.png', 'flags-medium/lv.png'),
(64, 'Lebanon', 'Pounds', 'LBP', '£', 'LB', 'flags/lb.png', 'flags-extralarge/lb.png', 'flags-large/lb.png', 'flags-medium/lb.png'),
(65, 'Liberia', 'Dollars', 'LRD', '$', 'LR', 'flags/lr.png', 'flags-extralarge/lr.png', 'flags-large/lr.png', 'flags-medium/lr.png'),
(66, 'Liechtenstein', 'Switzerland Francs', 'CHF', 'CHF', 'LI', 'flags/li.png', 'flags-extralarge/li.png', 'flags-large/li.png', 'flags-medium/li.png'),
(67, 'Lithuania', 'Litai', 'LTL', 'Lt', 'LT', 'flags/lt.png', 'flags-extralarge/lt.png', 'flags-large/lt.png', 'flags-medium/lt.png'),
(68, 'Luxembourg', 'Euro', 'EUR', '€', 'LU', 'flags/lu.png', 'flags-extralarge/lu.png', 'flags-large/lu.png', 'flags-medium/lu.png'),
(69, 'Macedonia', 'Denars', 'MKD', 'ден', 'MK', 'flags/mk.png', 'flags-extralarge/mk.png', 'flags-large/mk.png', 'flags-medium/mk.png'),
(70, 'Malaysia', 'Ringgits', 'MYR', 'RM', 'MY', 'flags/my.png', 'flags-extralarge/my.png', 'flags-large/my.png', 'flags-medium/my.png'),
(71, 'Malta', 'Euro', 'EUR', '€', 'MT', 'flags/mt.png', 'flags-extralarge/mt.png', 'flags-large/mt.png', 'flags-medium/mt.png'),
(72, 'Mauritius', 'Rupees', 'MUR', '₨', 'MU', 'flags/mu.png', 'flags-extralarge/mu.png', 'flags-large/mu.png', 'flags-medium/mu.png'),
(73, 'Mexico', 'Pesos', 'MXN', '$', 'MX', 'flags/mx.png', 'flags-extralarge/mx.png', 'flags-large/mx.png', 'flags-medium/mx.png'),
(74, 'Mongolia', 'Tugriks', 'MNT', '₮', 'MN', 'flags/mn.png', 'flags-extralarge/mn.png', 'flags-large/mn.png', 'flags-medium/mn.png'),
(75, 'Mozambique', 'Meticais', 'MZN', 'MT', 'MZ', 'flags/mz.png', 'flags-extralarge/mz.png', 'flags-large/mz.png', 'flags-medium/mz.png'),
(76, 'Namibia', 'Dollars', 'NAD', '$', 'NA', 'flags/na.png', 'flags-extralarge/na.png', 'flags-large/na.png', 'flags-medium/na.png'),
(77, 'Nepal', 'Rupees', 'NPR', '₨', 'NP', 'flags/np.png', 'flags-extralarge/np.png', 'flags-large/np.png', 'flags-medium/np.png'),
(78, 'Netherlands Antilles', 'Guilders', 'ANG', 'ƒ', 'NL', 'flags/nl.png', 'flags-extralarge/nl.png', 'flags-large/nl.png', 'flags-medium/nl.png'),
(79, 'Netherlands', 'Euro', 'EUR', '€', 'NL', 'flags/nl.png', 'flags-extralarge/nl.png', 'flags-large/nl.png', 'flags-medium/nl.png'),
(80, 'New Zealand', 'Dollars', 'NZD', '$', 'NZ', 'flags/nz.png', 'flags-extralarge/nz.png', 'flags-large/nz.png', 'flags-medium/nz.png'),
(81, 'Nicaragua', 'Cordobas', 'NIO', 'C$', 'NI', 'flags/ni.png', 'flags-extralarge/ni.png', 'flags-large/ni.png', 'flags-medium/ni.png'),
(82, 'Nigeria', 'Nairas', 'NGN', '₦', 'NG', 'flags/ng.png', 'flags-extralarge/ng.png', 'flags-large/ng.png', 'flags-medium/ng.png'),
(83, 'North Korea', 'Won', 'KPW', '₩', 'KP', 'flags/kp.png', 'flags-extralarge/kp.png', 'flags-large/kp.png', 'flags-medium/kp.png'),
(84, 'Norway', 'Krone', 'NOK', 'kr', 'NO', 'flags/no.png', 'flags-extralarge/no.png', 'flags-large/no.png', 'flags-medium/no.png'),
(85, 'Oman', 'Rials', 'OMR', '﷼', 'OM', 'flags/om.png', 'flags-extralarge/om.png', 'flags-large/om.png', 'flags-medium/om.png'),
(86, 'Pakistan', 'Rupees', 'PKR', '₨', 'PK', 'flags/pk.png', 'flags-extralarge/pk.png', 'flags-large/pk.png', 'flags-medium/pk.png'),
(87, 'Panama', 'Balboa', 'PAB', 'B/.', 'PA', 'flags/pa.png', 'flags-extralarge/pa.png', 'flags-large/pa.png', 'flags-medium/pa.png'),
(88, 'Paraguay', 'Guarani', 'PYG', 'Gs', 'PY', 'flags/py.png', 'flags-extralarge/py.png', 'flags-large/py.png', 'flags-medium/py.png'),
(89, 'Peru', 'Nuevos Soles', 'PEN', 'S/.', 'PE', 'flags/pe.png', 'flags-extralarge/pe.png', 'flags-large/pe.png', 'flags-medium/pe.png'),
(90, 'Philippines', 'Pesos', 'PHP', 'Php', 'PH', 'flags/ph.png', 'flags-extralarge/ph.png', 'flags-large/ph.png', 'flags-medium/ph.png'),
(91, 'Poland', 'Zlotych', 'PLN', 'zł', 'PL', 'flags/pl.png', 'flags-extralarge/pl.png', 'flags-large/pl.png', 'flags-medium/pl.png'),
(92, 'Qatar', 'Rials', 'QAR', '﷼', 'QA', 'flags/qa.png', 'flags-extralarge/qa.png', 'flags-large/qa.png', 'flags-medium/qa.png'),
(93, 'Romania', 'New Lei', 'RON', 'lei', 'RO', 'flags/ro.png', 'flags-extralarge/ro.png', 'flags-large/ro.png', 'flags-medium/ro.png'),
(94, 'Russia', 'Rubles', 'RUB', 'руб', 'RU', 'flags/ru.png', 'flags-extralarge/ru.png', 'flags-large/ru.png', 'flags-medium/ru.png'),
(95, 'Saint Helena', 'Pounds', 'SHP', '£', 'SH', 'flags/sh.png', 'flags-extralarge/sh.png', 'flags-large/sh.png', 'flags-medium/sh.png'),
(96, 'Saudi Arabia', 'Riyals', 'SAR', '﷼', 'SA', 'flags/sa.png', 'flags-extralarge/sa.png', 'flags-large/sa.png', 'flags-medium/sa.png'),
(97, 'Serbia', 'Dinars', 'RSD', 'Дин.', 'RS', 'flags/rs.png', 'flags-extralarge/rs.png', 'flags-large/rs.png', 'flags-medium/rs.png'),
(98, 'Seychelles', 'Rupees', 'SCR', '₨', 'SC', 'flags/sc.png', 'flags-extralarge/sc.png', 'flags-large/sc.png', 'flags-medium/sc.png'),
(99, 'Singapore', 'Dollars', 'SGD', '$', 'SG', 'flags/sg.png', 'flags-extralarge/sg.png', 'flags-large/sg.png', 'flags-medium/sg.png'),
(100, 'Slovenia', 'Euro', 'EUR', '€', 'SI', 'flags/si.png', 'flags-extralarge/si.png', 'flags-large/si.png', 'flags-medium/si.png'),
(101, 'Solomon Islands', 'Dollars', 'SBD', '$', 'SB', 'flags/sb.png', 'flags-extralarge/sb.png', 'flags-large/sb.png', 'flags-medium/sb.png'),
(102, 'Somalia', 'Shillings', 'SOS', 'S', 'SO', 'flags/so.png', 'flags-extralarge/so.png', 'flags-large/so.png', 'flags-medium/so.png'),
(103, 'South Africa', 'Rand', 'ZAR', 'R', 'ZA', 'flags/za.png', 'flags-extralarge/za.png', 'flags-large/za.png', 'flags-medium/za.png'),
(104, 'South Korea', 'Won', 'KRW', '₩', 'KR', 'flags/kr.png', 'flags-extralarge/kr.png', 'flags-large/kr.png', 'flags-medium/kr.png'),
(105, 'Spain', 'Euro', 'EUR', '€', 'ES', 'flags/es.png', 'flags-extralarge/es.png', 'flags-large/es.png', 'flags-medium/es.png'),
(106, 'Sri Lanka', 'Rupees', 'LKR', '₨', 'LK', 'flags/lk.png', 'flags-extralarge/lk.png', 'flags-large/lk.png', 'flags-medium/lk.png'),
(107, 'Sweden', 'Kronor', 'SEK', 'kr', 'SE', 'flags/se.png', 'flags-extralarge/se.png', 'flags-large/se.png', 'flags-medium/se.png'),
(108, 'Switzerland', 'Francs', 'CHF', 'CHF', 'CH', 'flags/ch.png', 'flags-extralarge/ch.png', 'flags-large/ch.png', 'flags-medium/ch.png'),
(109, 'Syria', 'Pounds', 'SYP', '£', 'SY', 'flags/sy.png', 'flags-extralarge/sy.png', 'flags-large/sy.png', 'flags-medium/sy.png'),
(110, 'Taiwan', 'New Dollars', 'TWD', 'NT$', 'TW', 'flags/tw.png', 'flags-extralarge/tw.png', 'flags-large/tw.png', 'flags-medium/tw.png'),
(111, 'Thailand', 'Baht', 'THB', '฿', 'TH', 'flags/th.png', 'flags-extralarge/th.png', 'flags-large/th.png', 'flags-medium/th.png'),
(112, 'Trinidad and Tobago', 'Dollars', 'TTD', 'TT$', 'TT', 'flags/tt.png', 'flags-extralarge/tt.png', 'flags-large/tt.png', 'flags-medium/tt.png'),
(113, 'Turkey', 'Lira', 'TRY', 'TL', 'TR', 'flags/tr.png', 'flags-extralarge/tr.png', 'flags-large/tr.png', 'flags-medium/tr.png'),
(114, 'Turkey', 'Liras', 'TRL', '£', 'TR', 'flags/tr.png', 'flags-extralarge/tr.png', 'flags-large/tr.png', 'flags-medium/tr.png'),
(115, 'Tuvalu', 'Dollars', 'TVD', '$', 'TV', 'flags/tv.png', 'flags-extralarge/tv.png', 'flags-large/tv.png', 'flags-medium/tv.png'),
(116, 'Ukraine', 'Hryvnia', 'UAH', '₴', 'UA', 'flags/ua.png', 'flags-extralarge/ua.png', 'flags-large/ua.png', 'flags-medium/ua.png'),
(117, 'United Kingdom', 'Pounds', 'GBP', '£', 'GB', 'flags/gb.png', 'flags-extralarge/gb.png', 'flags-large/gb.png', 'flags-medium/gb.png'),
(118, 'United States of America', 'Dollars', 'USD', '$', 'US', 'flags/us.png', 'flags-extralarge/us.png', 'flags-large/us.png', 'flags-medium/us.png'),
(119, 'Uruguay', 'Pesos', 'UYU', '$U', 'UY', 'flags/uy.png', 'flags-extralarge/uy.png', 'flags-large/uy.png', 'flags-medium/uy.png'),
(120, 'Uzbekistan', 'Sums', 'UZS', 'лв', 'UZ', 'flags/uz.png', 'flags-extralarge/uz.png', 'flags-large/uz.png', 'flags-medium/uz.png'),
(121, 'Vatican City', 'Euro', 'EUR', '€', 'VA', 'flags/va.png', 'flags-extralarge/va.png', 'flags-large/va.png', 'flags-medium/va.png'),
(122, 'Venezuela', 'Bolivares Fuertes', 'VEF', 'Bs', 'VE', 'flags/ve.png', 'flags-extralarge/ve.png', 'flags-large/ve.png', 'flags-medium/ve.png'),
(123, 'Vietnam', 'Dong', 'VND', '₫', 'VN', 'flags/vn.png', 'flags-extralarge/vn.png', 'flags-large/vn.png', 'flags-medium/vn.png'),
(124, 'Yemen', 'Rials', 'YER', '﷼', 'YE', 'flags/ye.png', 'flags-extralarge/ye.png', 'flags-large/ye.png', 'flags-medium/ye.png'),
(125, 'Zimbabwe', 'Zimbabwe Dollars', 'ZWD', 'Z$', 'ZW', 'flags/zw.png', 'flags-extralarge/zw.png', 'flags-large/zw.png', 'flags-medium/zw.png'),
(126, 'India', 'Rupees', 'INR', '₹', 'IN', 'flags/in.png', 'flags-extralarge/in.png', 'flags-large/in.png', 'flags-medium/in.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `countriesWithFlag`
--
ALTER TABLE `countriesWithFlag`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countriesWithFlag`
--
ALTER TABLE `countriesWithFlag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
